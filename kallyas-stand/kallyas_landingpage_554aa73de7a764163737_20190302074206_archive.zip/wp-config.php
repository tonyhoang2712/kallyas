<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kallyas');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@M[5[@VeNnyk4al#o+r;=aL)kN1xiKyg*X).9P3Y{AEQO,6zBcy>8.#ZyEpLL3D&');
define('SECURE_AUTH_KEY',  '1fgh5]J<_!lhhe;pnEU#m^*XT=^gc><k)zV-ehK>Rx6^DLhKaHJD`ia!?sARdC_m');
define('LOGGED_IN_KEY',    ']N+}@T,2LvsIy,ah/Z(K24E/80<Z![4o=Tn#/Bo^}~`ZjdA`-%mqnt|0,.z%aV>=');
define('NONCE_KEY',        'V8HGtB)l>qrY<oEOA~G4pK,W*dNZaY~F @. <bnM9sc//F5XZ`_52rHee#/DUp%_');
define('AUTH_SALT',        '{A{$`?5U4Y<mr]VTxtk.5dZusw9oJMA,e2AxbW5Z2R=$sLKD=>|Xh`%j@h W!({>');
define('SECURE_AUTH_SALT', '#jdBOES#E+:(yyGS]3KazCveJKphpIb~b/b%|m7lXD|PY|A^~v&gx#nP1;uQwqy=');
define('LOGGED_IN_SALT',   'CVbN71 bUhG:Le2S>NtdpTq$6=uW?@63 bY9SA<nACcxPc1EOoY3VkN_SQ:$AR1T');
define('NONCE_SALT',       'pthHYoi}xvqg`+Fa`FC6f, ->@_N;Su^Y@o]`]1F}o]Y{m~;K_#=.~<?GI7Y39lN');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
